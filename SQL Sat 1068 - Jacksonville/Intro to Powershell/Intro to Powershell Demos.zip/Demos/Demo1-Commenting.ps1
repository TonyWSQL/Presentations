
# using the hash mark will comment every thing after it in that line
# just like the -- comment in T-SQL

#  <#...#> Will let you comment multiple lines and/or parts of a given line
# just like the /*...*/ comment in T-SQL

<# 
   this is a 
   comment spanning
   multiple lines   
#>

#region Sections of your code


#endregion
